'use strict'

const express = require('express');
const controller = require('../controllers/controllers')
const router = express.Router()

// Escriban sus rutas acá
// Siéntanse libres de dividir entre archivos si lo necesitan

router.get('/cats', (req, res) => {
    res.status(200).json(controller.listCats());
});

router.post('/cats', (req, res) => {
    const { name } = req.body;

    try {
        if (name) {
            controller.addCat(name);
            let cats = controller.listCats();
            let cat = cats.find(c => c.name === name);
            res.status(201).json({msg: "Exito", data: cat});
        }
    } catch (error) {
        res.status(400).json({error: `${name} already exists`});
    }
});

router.get('/accessories', (req, res) => {
    const { type, color } = req.query;

    if (type || color) {
        return res.status(200).send(controller.getAccessories(type, color));
    }
    res.status(200).send(controller.getAccessories());
});

router.put('/accessories/:id', (req, res) => {
    const { id } = req.params;
    let { type, color, description } = req.body;

    let obj = {
        id: parseInt(id),
        type,
        color,
        description
    }
    if (!obj.type) {
        delete obj.type;
    }
    if (!obj.color) {
        delete obj.color;
    }
    if (!obj.description) {
        delete obj.description;
    }
    try {
        let accessory = controller.modifyAccessory(obj);
        delete accessory.popularity;
        res.status(200).send(accessory);
    } catch (error) {
        res.status(404).send({error: "accesorio no encontrado"});
    }
});

router.post('/accessories', (req, res) => {
    let obj = req.body;
    try {
        controller.addAccessory(obj);
        res.status(201).send({message: `El accesorio ${obj.color} ${obj.type} fue agregado correctamente`});
    } catch (error) {
        res.status(400).json({error: error.message});
    }    
});

router.delete('/accessories/:id', (req, res) => {
    let { id } = req.params;
    try {
        controller.deleteAccessory(parseInt(id));
        res.status(200).json({message: `El accesorio con el id ${ id } fue eliminado correctamente`});
    } catch (error) {
        res.status(404).json({error: error.message});
    }
});

router.post('/cats/accessories', (req, res) => {
    let { catName, catAccessoryId } = req.body;

    try {
        controller.addCatAccessory(catName, parseInt(catAccessoryId));
        res.status(200).json({msg: "Exito"});
    } catch (error) {
        if ((error.message === `El gato ${ catName } no existe`)) {
            return res.status(404).json({error: error.message});
        }
        if ((error.message === `El gato ${ catName } ya tiene el accesorio puesto`)) {
            return res.status(400).json({error: error.message});
        }
        res.status(404).json({error: "accesorio no encontrado"});
    }
});

// Hint:  investigá las propiedades del objeto Error en JS para acceder al mensaje en el mismo.
module.exports = router