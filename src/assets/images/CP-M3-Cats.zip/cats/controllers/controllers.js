/// =========================================================================== ///
/// =============================== HENRY-CATS ================================ ///
/// =========================================================================== ///

'use strict'

const res = require("express/lib/response")
const { type } = require("express/lib/response")

let cats = []
let accessories = []

module.exports = {

  reset: function () {
    // No es necesario modificar esta función. La usamos para "limpiar" los arreglos entre test y test.

    cats = []
    accessories = []
  },

  // ==== COMPLETAR LAS SIGUIENTES FUNCIONES (vean los test de `controller.js`) =====

  addCat: function (name) {
    // Agrega un nuevo felin@, verificando que no exista anteriormente en base a su nombre.
    // En caso de existir, no se agrega y debe arrojar el Error ('El gato o gata ya existe') >> ver JS throw Error
    // Debe tener una propiedad <age> que inicialmente debe ser '1 year'.
    // Debe tener una propiedad <color> que inicialmente es un array vacío.
    // Debe tener una propiedad <accesories> que inicialmente es un array vacío.
    // El gato o gata debe guardarse como un objeto con el siguiente formato:
    // { name: name,  age: '1 year' , color: []}
    // En caso exitoso debe retornar el string '<nombre del gato o gata> fue creado correctamente'.

    let result = cats.find(c => c.name === name);
    if (result === undefined) {
      let cat = {name: name, age: "1 year", color: [], accessories: []}
      cats.push(cat);
      return cat.name + " fue creado correctamente";
    }
    if (result !== undefined) {
      throw new Error("El gato o gata ya existe");
    }    
    
  },

  listCats: function (age) {
    // En caso de recibir el parámetro <age>, devuelve sólo los gatos correspondientes a dicho age.
    // Si no recibe parámetro, devuelve un arreglo con todos los gatos.
    if (!age) {
      return cats;
    }
    else{
      cats = cats.filter(c => c.age === age);
      return cats;
    }
  },

  addAccessory: function ({ id, color, type, description }) {
    // Agrega un nuevo accesorio.
    // Si el accesorio ya existe, no es agregado y arroja un Error ('El accesorio con el id <id> ya existe')
    // Debe devolver el mensaje 'El accesorio <type> fue agregado correctamente'
    // Inicialmente debe guardar la propiedad <popularity> del accesorio como 'low' por defecto
    // Si la descripción supera los 140 caracteres, debe arrojar un error

    if (description.length > 140) {
      throw new Error("La descripción supera los 140 caracteres");
    }
    let catAccessory = accessories.find(e => e.id === id);
    if (catAccessory) {
      throw new Error(`El accesorio con el id ${ id } ya existe`);
    }
    let accessory = { id, color, type, description, popularity: "low" };
    accessories.push(accessory);
    
  },

  getAccessories: function (type, color) {
    // Devuelve un array con todos los accesorios.
    // Si recibe parámetro "type", debe retornar  los accesorios que coincidan con el tipo.
    // Si recibe parámetro "color" debe retornar los accesorios que coincidan con el color
    // Si recibe ambos parámetros, se devuelven los accesorios que coincidan con el color o con el tipo

    let accessoriesRequested = [];
    if (type || color) {
      accessoriesRequested = accessories.filter((a) => a.type === type || a.color === color);
      return accessoriesRequested;
    }
    
    return accessories;
  },

  deleteAccessory: function (id) {
    // Elimina un accesorio del array
    // Si el id no existe dentro del array de accesorios, arrojar un Error ('El accesorio con el id <id> no fue encontrado')
    // Una vez eliminado el accesorio del array, devolver un mensaje que diga 'El accesorio con el id <id> fue eliminado correctamente'
    
    if (!accessories.find((e) => e.id === id)){
      throw new Error(`El accesorio con el id ${ id } no fue encontrado`);
    }
    accessories = accessories.filter((e) => e.id !== id);
    return `El accesorio con el id ${ id } fue eliminado correctamente`;

  },

  modifyAccessory: function (obj) {
    // Modifica un accesorio del array
    // Si el id no existe dentro del array de accesorios arrojar un Error ('accesorio no encontrado')
    // Si el objeto viene vacio, arrojar un Error ('No se detectaron cambios a aplicar')
    // Una vez modificado el accesorio del array, devolver el accesorio modificado    
    
    if (Object.keys(obj).length === 0) {
      throw new Error("No se detectaron cambios a aplicar");
    }
    let accessory = accessories.find((e) => e.id === obj.id);
    if (!accessory) {
      throw new Error("accesorio no encontrado");
    }
    accessories = accessories.map((e) => {
      if (e.id === obj.id) {
        return {...e, ...obj}
      }
      return e;
    });
    return accessories.find((e) => e.id === obj.id);
    
  },

  increaseAccesoryPopularity: function (accessoryId) {
    // Este método es complementario a 'addCatAccessory'
    // Actualiza la propiedad <popularity> del accesorio,
    // Si se actualizó la popularidad del accesorio, devolver true
    // Si no se actualizó la popularidad del accesorio, debe devolver false
    let popularity = cats.map((e) => e.accessories);

        let cont = 0;
        popularity.map((e) =>
          e.map((e) => {
            if (e == accessoryId) {
              cont++;
            }
          })
        );

        if (cont < 2) {
          this.modifyAccessory({ popularity: "low", id: accessoryId });
        } else if (cont == 2) {
          this.modifyAccessory({ popularity: "average", id: accessoryId });
        } else {
          this.modifyAccessory({ popularity: "high", id: accessoryId });
        }
  },

  addCatAccessory: function (catName, accessoryId) {
    // Agrega un accesorio a un felin@
    // Si el felin@ ya tiene puesto el accesorio, arrojar un Error('El gato <nombre_gato> ya tiene el accesorio puesto') y no lo agrega
    // Si el gato no existe arrojar un Error ('El gato <nombre_gato> no existe')
    // Si el id de accesorio no existe arrojar un Error ('accesorio no encontrado' y no actualiza la popularidad)
    let index
    for (let i = 0; i < cats.length; i++) {
      if (cats[i].name == catName) {
            index = i
      }
    }
    if (index === undefined) {
      throw new Error(`El gato ${catName} no existe`);
    }
    let accesory = this.getAccessories().find((e) => e.id == accessoryId);
    if (!accesory) {
      throw new Error(`Accesorio no encontrado`);
    }
    if (cats[index].accessories.find((e) => e == accessoryId)) {
       throw new Error(`El gato ${catName} ya tiene el accesorio puesto`);
    }

    cats[index].accessories.push(accessoryId)

    this.increaseAccesoryPopularity(accessoryId)

    return `El accesorio Bun fue agregado a ${catName} con exito`;

  },

  getAccessoryPopularity: function (accessoryId) {
    //Devuelve la popularidad de un accesorio
    // Para eso deberás comprobar cuantos gatos visten el accesorio recibido por parámetros (es un id)
    // Si la cantidad de gatos que visten el accesorio son 2, entonces la popularidad del accesorio debe valer 'average'
    // Si la cantidad de gatos que visten el accesorio son 3, entonces la popularidad del accesorio debe valer 'high'
    let accessory = this.getAccessories().find((e) => e.id === accessoryId)
    return accessory.popularity;
  },
}
